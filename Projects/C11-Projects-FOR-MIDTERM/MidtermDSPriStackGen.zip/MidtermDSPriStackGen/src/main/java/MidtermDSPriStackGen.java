/**
 *
 * @author Soliloquy Yarrow -- Student #2342261 JAC-FSD-08
 */
public class MidtermDSPriStackGen {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
